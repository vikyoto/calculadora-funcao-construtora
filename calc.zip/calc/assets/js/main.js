function Calculadora(){ // função factory
  this.display = document.querySelector(".display");

  this.inicia = () => { //inicia tudo e começa procurando os metodos caputraCliques e capturaEnter
    this.capturaCliques();
    this.capturaEnter();
  };

  this.capturaEnter = () => {
    document.addEventListener("keyup", event => {
      if (event.keyCode === 13){ //caputra codigo 13 (qualquer enter do teclado)
        this.realizaConta(); //chama metodo realiza conta
      }
    });
  };

  this.capturaCliques = () => {
    document.addEventListener("click", e => { // checa por cliques, qual botao foi selecionado
      const el = e.target; //qual botao pressionado
      if (el.classList.contains("btn-num")) this.addNumDisplay(el); // condições (caso apertar btn-num, direciona para tal metodo)
      if (el.classList.contains("btn-clear")) this.clear(); // condições (caso apertar btn-clear, direciona para tal metodo)
      if (el.classList.contains("btn-del")) this.del(); // condições (caso apertar btn-del, direciona para tal metodo)
      if (el.classList.contains("btn-eq")) this.realizaConta(); // condições (caso apertar btn-eq, direciona para tal metodo)
    });
  };

  this.realizaConta = () => {
    try{ //tenta
      const conta = eval(this.display.value); //avalia se é uma conta válida

      if(!conta){
        alert("Conta invalida"); // se conta = NAN/false retrnar conta invalida
        return;
      }

      this.display.value = conta;
    }catch(e){
      alert("Conta Invalida"); // se der algum erro no meio do caminho retornar conta invalida
      return;
    }
  };

  this.addNumDisplay = el => { //recebe um elemento
    this.display.value += el.innerText; //pega o display e adiciona, alem doque ja esta no display + o texto do botao
    this.display.focus(); // cada vez que clica no botao, adiciona o botao e mantem o foco no display
  };

  this.clear = () => this.display.value = ""; // display fica vazio
  this.del = () => this.display.value = this.display.value.slice(0, -1); // apaga 1 elemento por vez no display

}

const calculadora = new Calculadora(); //cria o objeto em si
calculadora.inicia(); // chama o metodo inicia (tudo começa por aqui)